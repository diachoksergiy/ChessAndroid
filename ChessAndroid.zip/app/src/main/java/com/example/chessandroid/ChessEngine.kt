package com.example.chessandroid

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.move.Move
import com.github.bhlangonijr.chesslib.move.MoveGenerator

interface ChessEngine {
    fun chooseMove(board: Board, strength: Int): Move?
}

/**
 * Працює без нативних бібліотек:
 * 1) генерує всі легальні ходи
 * 2) якщо є взяття/шах — віддає перевагу
 * 3) інакше випадково, але з легким скорингом
 *
 * Це потрібно, щоб проєкт точно запускався одразу.
 * Stockfish (UCI) додамо наступним кроком.
 */
class HeuristicRandomEngine : ChessEngine {

    override fun chooseMove(board: Board, strength: Int): Move? {
        val moves = MoveGenerator.generateLegalMoves(board)
        if (moves.isEmpty()) return null

        // Quick preference: captures and checks
        val scored = moves.map { m ->
            var score = 0
            val before = board.clone()
            val targetPiece = before.getPiece(m.to)
            if (targetPiece != null && targetPiece.toString() != "NONE") score += 50

            before.doMove(m)
            if (before.isKingAttacked) score += 30

            // Strength adds slight randomness reduction
            score += (0..(10 - strength.coerceIn(1,10))).random()
            score to m
        }

        return scored.maxBy { it.first }.second
    }
}
