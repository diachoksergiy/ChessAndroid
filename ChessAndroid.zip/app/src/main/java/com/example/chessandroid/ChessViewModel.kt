package com.example.chessandroid

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.move.MoveGenerator

data class UiState(
    val header: String = "",
    val sub: String = "",
    val pieces: Map<Square, String> = emptyMap(),
    val selectedSquare: Square? = null,
    val legalTargets: Set<Square> = emptySet(),
    val checkSquare: Square? = null,
    val aiStrength: Int = 4
)

class ChessViewModel {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var mode: GameMode = GameMode.VS_AI
    private val board = Board()

    private var selected: Square? = null
    private var legalMovesFromSelected: List<Move> = emptyList()

    private var aiStrength: Int = 4
    private val aiEngine: ChessEngine = HeuristicRandomEngine()

    // Bluetooth
    private var bt: BluetoothLink? = null
    private var btSide: Side? = null // side for THIS phone in BT mode

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        reset(GameMode.VS_AI)
    }

    fun reset(newMode: GameMode) {
        mode = newMode
        board.loadFromFen(Board.STARTING_POSITION_FEN)
        selected = null
        legalMovesFromSelected = emptyList()

        bt?.closeQuiet()
        bt = null
        btSide = null

        publish("Гра почалась", if (mode == GameMode.VS_AI) "Ти граєш за БІЛИХ" else "")
    }

    fun setAiStrength(v: Int) {
        aiStrength = v.coerceIn(1, 10)
        _uiState.value = _uiState.value.copy(aiStrength = aiStrength)
    }

    fun onTapSquare(square: Square) {
        if (mode == GameMode.BLUETOOTH && bt == null) {
            publish("Bluetooth не підключено", "Спочатку підключись (Host/Join).")
            return
        }

        val piece = board.getPiece(square)
        val sideToMove = board.sideToMove

        // If no selection yet: select own piece
        if (selected == null) {
            if (piece != Piece.NONE && piece.pieceSide == sideToMove) {
                selectSquare(square)
            }
            return
        }

        // Re-select own piece
        if (piece != Piece.NONE && piece.pieceSide == sideToMove) {
            selectSquare(square)
            return
        }

        // Try move
        val move = legalMovesFromSelected.firstOrNull { it.to == square }
        if (move != null) {
            doMove(move)
        } else {
            // clear selection
            selected = null
            legalMovesFromSelected = emptyList()
            publishState()
        }
    }

    private fun selectSquare(square: Square) {
        selected = square
        val all = MoveGenerator.generateLegalMoves(board)
        legalMovesFromSelected = all.filter { it.from == square }
        publishState()
    }

    private fun doMove(move: Move) {
        // Promotion: if pawn reaches last rank, default to queen
        val moving = board.getPiece(move.from)
        val promoMove = if (moving.pieceType == PieceType.PAWN && (move.to.rank.ordinal == 0 || move.to.rank.ordinal == 7)) {
            Move(move.from, move.to, Piece.WHITE_QUEEN) // chesslib uses promotion piece; side ignored for black? ok for UI; generator handles
        } else move

        val ok = board.doMove(promoMove)
        if (!ok) {
            publish("Нелегальний хід", "")
            publishState()
            return
        }

        selected = null
        legalMovesFromSelected = emptyList()
        publishState()

        val uci = toUci(move)
        when (mode) {
            GameMode.VS_AI -> maybeAiMove()
            GameMode.BLUETOOTH -> bt?.sendLine("MOVE $uci")
            else -> {}
        }
    }

    private fun maybeAiMove() {
        if (board.sideToMove != Side.BLACK) return // human = white
        scope.launch {
            delay(150) // tiny pause for UX
            val aiMove = aiEngine.chooseMove(board, aiStrength)
            if (aiMove != null) {
                board.doMove(aiMove)
                withContext(Dispatchers.Default) { publishState() }
            }
        }
    }

    // ===== Bluetooth =====

    fun startBtHost(onStatus: (String) -> Unit) {
        reset(GameMode.BLUETOOTH)
        btSide = Side.WHITE // host = white (simple rule)
        onStatus("Host: очікування підключення…")
        scope.launch {
            try {
                bt = BluetoothLink.host()
                onStatus("Підключено! Ти: БІЛІ")
                listenBt(onStatus)
                publishState()
            } catch (e: Exception) {
                onStatus("Помилка Host: ${e.message}")
            }
        }
    }

    fun startBtJoin(mac: String, onStatus: (String) -> Unit) {
        reset(GameMode.BLUETOOTH)
        btSide = Side.BLACK // client = black
        onStatus("Join: підключення до $mac…")
        scope.launch {
            try {
                bt = BluetoothLink.join(mac)
                onStatus("Підключено! Ти: ЧОРНІ")
                listenBt(onStatus)
                publishState()
            } catch (e: Exception) {
                onStatus("Помилка Join: ${e.message}")
            }
        }
    }

    private suspend fun listenBt(onStatus: (String) -> Unit) {
        val link = bt ?: return
        try {
            while (true) {
                val line = link.readLine() ?: break
                if (line.startsWith("MOVE ")) {
                    val uci = line.removePrefix("MOVE ").trim()
                    val mv = fromUci(uci)
                    if (mv != null) {
                        board.doMove(mv)
                        selected = null
                        legalMovesFromSelected = emptyList()
                        publishState()
                    }
                } else if (line.startsWith("MSG ")) {
                    onStatus(line.removePrefix("MSG "))
                }
            }
        } catch (e: Exception) {
            onStatus("BT роз'єднано: ${e.message}")
        } finally {
            link.closeQuiet()
            bt = null
        }
    }

    fun isMyTurnInBluetooth(role: BtRole): Boolean {
        if (mode != GameMode.BLUETOOTH) return true
        val side = btSide ?: return false
        return board.sideToMove == side
    }

    // ===== UI helpers =====

    fun rcToSquare(r: Int, c: Int): Square {
        // r=0 is top (rank 8), c=0 is file A
        val fileChar = ('A'.code + c).toChar()
        val rankChar = ('8'.code - r).toChar()
        return Square.valueOf("$fileChar$rankChar")
    }

    private fun publish(header: String, sub: String) {
        _uiState.value = _uiState.value.copy(header = header, sub = sub, aiStrength = aiStrength)
        publishState()
    }

    private fun publishState() {
        val map = mutableMapOf<Square, String>()
        for (sq in Square.values()) {
            val p = board.getPiece(sq)
            if (p != Piece.NONE) map[sq] = pieceToSymbol(p)
        }

        val legalTargets = legalMovesFromSelected.map { it.to }.toSet()
        val checkSq = if (board.isKingAttacked) {
            // square of side to move king
            findKingSquare(board, board.sideToMove)
        } else null

        val status = when {
            board.isMated -> "Мат. ${if (board.sideToMove == Side.WHITE) "Чорні" else "Білі"} перемогли"
            board.isDraw -> "Нічия"
            board.isKingAttacked -> "Шах! Хід: ${sideToText(board.sideToMove)}"
            else -> "Хід: ${sideToText(board.sideToMove)}"
        }

        _uiState.value = _uiState.value.copy(
            header = status,
            sub = when (mode) {
                GameMode.LOCAL -> "Локальна гра (на одному телефоні)"
                GameMode.VS_AI -> "Ти = Білі, AI = Чорні"
                GameMode.BLUETOOTH -> "Bluetooth: ${if (bt != null) "підключено" else "не підключено"}"
            },
            pieces = map,
            selectedSquare = selected,
            legalTargets = legalTargets,
            checkSquare = checkSq,
            aiStrength = aiStrength
        )
    }

    private fun sideToText(s: Side): String = if (s == Side.WHITE) "Білі" else "Чорні"

    private fun pieceToSymbol(p: Piece): String = when (p) {
        Piece.WHITE_KING -> "♔"
        Piece.WHITE_QUEEN -> "♕"
        Piece.WHITE_ROOK -> "♖"
        Piece.WHITE_BISHOP -> "♗"
        Piece.WHITE_KNIGHT -> "♘"
        Piece.WHITE_PAWN -> "♙"
        Piece.BLACK_KING -> "♚"
        Piece.BLACK_QUEEN -> "♛"
        Piece.BLACK_ROOK -> "♜"
        Piece.BLACK_BISHOP -> "♝"
        Piece.BLACK_KNIGHT -> "♞"
        Piece.BLACK_PAWN -> "♟"
        else -> ""
    }

    private fun findKingSquare(b: Board, side: Side): Square? {
        for (sq in Square.values()) {
            val p = b.getPiece(sq)
            if (p != Piece.NONE && p.pieceSide == side && p.pieceType == PieceType.KING) return sq
        }
        return null
    }

    // UCI: e2e4, g7g8q
    private fun toUci(m: Move): String {
        val from = m.from.name.lowercase()
        val to = m.to.name.lowercase()
        val promo = if (m.promotion != null && m.promotion != Piece.NONE) {
            when (m.promotion.pieceType) {
                PieceType.QUEEN -> "q"
                PieceType.ROOK -> "r"
                PieceType.BISHOP -> "b"
                PieceType.KNIGHT -> "n"
                else -> ""
            }
        } else ""
        return from + to + promo
    }

    private fun fromUci(uci: String): Move? {
        val s = uci.trim().lowercase()
        if (s.length < 4) return null
        val from = Square.valueOf(s.substring(0,2).uppercase())
        val to = Square.valueOf(s.substring(2,4).uppercase())
        val promo = if (s.length >= 5) s[4] else null
        return if (promo != null) {
            val piece = when (promo) {
                'q' -> if (board.sideToMove == Side.WHITE) Piece.WHITE_QUEEN else Piece.BLACK_QUEEN
                'r' -> if (board.sideToMove == Side.WHITE) Piece.WHITE_ROOK else Piece.BLACK_ROOK
                'b' -> if (board.sideToMove == Side.WHITE) Piece.WHITE_BISHOP else Piece.BLACK_BISHOP
                'n' -> if (board.sideToMove == Side.WHITE) Piece.WHITE_KNIGHT else Piece.BLACK_KNIGHT
                else -> Piece.NONE
            }
            Move(from, to, piece)
        } else Move(from, to)
    }
}
