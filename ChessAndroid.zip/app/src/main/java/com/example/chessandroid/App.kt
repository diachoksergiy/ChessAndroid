package com.example.chessandroid

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

enum class GameMode {
    LOCAL, VS_AI, BLUETOOTH
}

@Composable
fun App(vm: ChessViewModel) {
    var mode by remember { mutableStateOf(GameMode.VS_AI) }
    var btRole by remember { mutableStateOf(BtRole.HOST) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        TopBar(
            mode = mode,
            onModeChange = { mode = it; vm.reset(mode) },
            onNewGame = { vm.reset(mode) }
        )
        Spacer(Modifier.height(8.dp))

        when (mode) {
            GameMode.BLUETOOTH -> {
                BluetoothPanel(
                    vm = vm,
                    role = btRole,
                    onRoleChange = { btRole = it },
                )
                Spacer(Modifier.height(8.dp))
                ChessBoardScreen(vm = vm, enabled = vm.isMyTurnInBluetooth(btRole))
            }
            else -> {
                ChessBoardScreen(vm = vm, enabled = true)
            }
        }

        Spacer(Modifier.height(8.dp))
        StatusPanel(vm = vm, mode = mode)
    }
}

@Composable
private fun TopBar(
    mode: GameMode,
    onModeChange: (GameMode) -> Unit,
    onNewGame: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("ChessAndroid", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.weight(1f))
        Button(onClick = onNewGame) { Text("Нова гра") }
    }

    Spacer(Modifier.height(8.dp))

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Режим:", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.width(8.dp))

        SegmentedButtonRow {
            SegButton("Локально", mode == GameMode.LOCAL) { onModeChange(GameMode.LOCAL) }
            SegButton("Проти AI", mode == GameMode.VS_AI) { onModeChange(GameMode.VS_AI) }
            SegButton("Bluetooth", mode == GameMode.BLUETOOTH) { onModeChange(GameMode.BLUETOOTH) }
        }
    }
}

@Composable
private fun SegmentedButtonRow(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
private fun RowScope.SegButton(text: String, selected: Boolean, onClick: () -> Unit) {
    val colors = ButtonDefaults.buttonColors(
        containerColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer
    )
    Button(
        onClick = onClick,
        colors = colors,
        modifier = Modifier.weight(1f)
    ) { Text(text) }
}

@Composable
private fun StatusPanel(vm: ChessViewModel, mode: GameMode) {
    val state by vm.uiState.collectAsState()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(state.header, style = MaterialTheme.typography.titleMedium)
            if (state.sub.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(state.sub, style = MaterialTheme.typography.bodyMedium)
            }

            if (mode == GameMode.VS_AI) {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Складність AI:", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.width(8.dp))
                    Slider(
                        value = state.aiStrength.toFloat(),
                        onValueChange = { vm.setAiStrength(it.toInt()) },
                        valueRange = 1f..10f,
                        steps = 8,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("${state.aiStrength}")
                }
                Text(
                    "Поки що AI = "розумніший випадковий" (підбирає краще взяття/шах). Stockfish підключимо наступним кроком.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
