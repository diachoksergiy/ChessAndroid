package com.example.chessandroid

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp

enum class BtRole { HOST, JOIN }

@Composable
fun BluetoothPanel(
    vm: ChessViewModel,
    role: BtRole,
    onRoleChange: (BtRole) -> Unit,
) {
    var mac by remember { mutableStateOf(TextFieldValue("00:11:22:33:44:55")) }
    var status by remember { mutableStateOf("Порада: на другому телефоні увімкни Bluetooth і дізнайся MAC (або через "Bluetooth MAC" додаток).") }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("Bluetooth", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                FilterChip(
                    selected = role == BtRole.HOST,
                    onClick = { onRoleChange(BtRole.HOST) },
                    label = { Text("Host (Білі)") }
                )
                Spacer(Modifier.width(8.dp))
                FilterChip(
                    selected = role == BtRole.JOIN,
                    onClick = { onRoleChange(BtRole.JOIN) },
                    label = { Text("Join (Чорні)") }
                )
            }

            if (role == BtRole.JOIN) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = mac,
                    onValueChange = { mac = it },
                    label = { Text("MAC адреса хоста") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (role == BtRole.HOST) {
                            vm.startBtHost { status = it }
                        } else {
                            vm.startBtJoin(mac.text.trim()) { status = it }
                        }
                    }
                ) { Text(if (role == BtRole.HOST) "Старт Host" else "Підключитись") }
            }

            Spacer(Modifier.height(8.dp))
            Text(status, style = MaterialTheme.typography.bodySmall)
        }
    }
}
