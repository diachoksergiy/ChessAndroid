package com.example.chessandroid

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color

@Composable
fun ChessBoardScreen(vm: ChessViewModel, enabled: Boolean) {
    val s by vm.uiState.collectAsState()

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(8.dp)
        ) {
            Column {
                for (r in 0 until 8) {
                    Row {
                        for (c in 0 until 8) {
                            val square = vm.rcToSquare(r, c)
                            val base = if ((r + c) % 2 == 0) Color(0xFFE8E2D0) else Color(0xFF769656)
                            val isSelected = s.selectedSquare == square
                            val isMove = s.legalTargets.contains(square)
                            val isCheck = s.checkSquare == square

                            val bg = when {
                                isSelected -> Color(0xFF3B82F6)
                                isMove -> Color(0xFF22C55E)
                                isCheck -> Color(0xFFEF4444)
                                else -> base
                            }

                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(bg)
                                    .clickable(enabled = enabled) { vm.onTapSquare(square) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = s.pieces[square] ?: "",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            if (enabled) "Тап: фігура → хід" else "Очікуємо хід суперника…",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
