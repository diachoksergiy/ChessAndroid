package com.example.chessandroid

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.UUID

/**
 * Мінімальний RFCOMM (SPP) канал.
 * Для простоти: Host = WHITE, Join = BLACK.
 *
 * ПРИМІТКА:
 * - Для підключення пристрої мають бути спарені в системних налаштуваннях Bluetooth.
 * - Ми використовуємо стандартний UUID для SPP.
 */
class BluetoothLink private constructor(
    private val socket: BluetoothSocket,
    private val reader: BufferedReader,
    private val writer: BufferedWriter,
    private val serverSocket: BluetoothServerSocket? = null
) {
    fun sendLine(line: String) {
        writer.write(line)
        writer.write("\n")
        writer.flush()
    }

    fun readLine(): String? = reader.readLine()

    fun closeQuiet() {
        try { writer.close() } catch (_: Exception) {}
        try { reader.close() } catch (_: Exception) {}
        try { socket.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
    }

    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

        fun host(): BluetoothLink {
            val adapter = BluetoothAdapter.getDefaultAdapter() ?: error("Bluetooth не підтримується")
            if (!adapter.isEnabled) error("Увімкни Bluetooth")

            val server = adapter.listenUsingRfcommWithServiceRecord("ChessAndroid", SPP_UUID)
            val sock = server.accept() ?: error("Не вдалося прийняти підключення")

            val reader = BufferedReader(InputStreamReader(sock.inputStream))
            val writer = BufferedWriter(OutputStreamWriter(sock.outputStream))
            return BluetoothLink(sock, reader, writer, server)
        }

        fun join(mac: String): BluetoothLink {
            val adapter = BluetoothAdapter.getDefaultAdapter() ?: error("Bluetooth не підтримується")
            if (!adapter.isEnabled) error("Увімкни Bluetooth")

            val device: BluetoothDevice = adapter.getRemoteDevice(mac)
            val sock = device.createRfcommSocketToServiceRecord(SPP_UUID)
            adapter.cancelDiscovery()
            sock.connect()

            val reader = BufferedReader(InputStreamReader(sock.inputStream))
            val writer = BufferedWriter(OutputStreamWriter(sock.outputStream))
            return BluetoothLink(sock, reader, writer, null)
        }
    }
}
