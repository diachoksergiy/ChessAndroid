package com.example.chessandroid

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {

    private val requestBtPerms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* handled in UI */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ask BT permissions on Android 12+ (safe to request; user can deny).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestBtPerms.launch(arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN
            ))
        }

        setContent {
            val vm = remember { ChessViewModel() }
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    App(vm = vm)
                }
            }
        }
    }
}
